<?php require_once "setup.php";

echo "yes";

?>